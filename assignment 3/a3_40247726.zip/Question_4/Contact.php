<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>HomeFinder</title>
        <link rel="stylesheet" href="Question_4.css">
        <script src="Question_4.js"></script>
    </head>
    <body>


        <div class="wrapper">
            <div class="sidebar">
                <h2>Navigation</h2>
                <ul>
                    <li><a class="navigation"
                            href="Home.php">Home Page</a></li>
                    <li><a class="navigation"
                    href="Create_ACC.php"> Create an account </a></li>
                    <li><a class="navigation"
                            href="Find_Dog-Cat.php">  Find A Dog/Cat</a></li>
                    <li><a class="navigation" href="DogCare.php">
                            Dog Care</a></li>
                    <li><a class="navigation" href="CatCare.php">Cat
                            Care</a></li>
                    <li><a class="navigation" href="Login_Page.php">
                        Have A Pet To Give
                        Away</a></li>
                    <li><a class="navigation active" href="Contact.php">
                            Contact Us</a></li>
                            <li><a class="navigation" href="Logout.php">
                        Logout</a></li>
                </ul>
            </div>

           
            <div class="main_content">
                <?php include('Header.html'); ?>
                <div class="content">
                    <ul>
                        <li>My name: Andrew Harissi Dagher</li>
                        <li>My studnet ID: 40247726</li>
                        <li>email: andrew.h.dagher@gmail.com</li>
                    </ul>





                </div>
                <div style="padding-left: 50px;margin-top:50%">

                <?php include('Footer.html'); ?>
                </div>
            </div>


    
        
  
  </body>
</html>